Aravis 0.9.3 (0.10) for MinGW-w64
====================================

Layout
  include/aravis-0.10/   Aravis headers (include <arv.h>)
  include/glib-2.0/      GLib headers, which <arv.h> needs
  include/libxml2/       libxml2 headers
  include/libusb-1.0/    libusb headers
  lib/                   import libraries: -laravis-0.10 plus its dependencies
  lib/glib-2.0/include/  glibconfig.h
  lib/pkgconfig/         aravis-0.10.pc (relocatable; spells out all flags)
  bin/                   runtime DLLs, including libaravis-0.10-0.dll and the tools
  licenses/              licence texts for everything redistributed

Compiling against it
  gcc myapp.c -o myapp.exe $(pkg-config --cflags --libs aravis-0.10)
or, without pkg-config:
  gcc myapp.c -o myapp.exe \
    -I<package>/include/aravis-0.10 -I<package>/include/glib-2.0 \
    -I<package>/lib/glib-2.0/include \
    -L<package>/lib -laravis-0.10 -lglib-2.0 -lgobject-2.0 -lgio-2.0 -lgmodule-2.0 -lxml2 -lusb-1.0 -lz

Running
  Put <package>/bin on PATH, or copy its DLLs next to your executable: MinGW
  searches the executable's own directory first, and the DLLs here are the ones
  the import libraries were built against.
