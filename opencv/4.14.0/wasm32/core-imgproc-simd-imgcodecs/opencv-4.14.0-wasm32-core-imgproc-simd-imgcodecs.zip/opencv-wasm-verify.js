// Usage: opencv-wasm-verify.js <opencv.js> <opencv_js.wasm|-> <imgcodecs> <wasm-out>
const fs = require('fs');

const [jsPath, wasmPath, wantCodecs, wasmOut] = process.argv.slice(2);
const js = fs.readFileSync(jsPath, 'utf8');

// A single-file build is a ~11 MB script embedding a ~8 MB base64 blob.
// Matching that with a regex is not possible: V8 aborts with "Maximum call
// stack size exceeded" on a multi-megabyte quantified match. The text is
// scanned character by character instead, and every long candidate is decoded
// until one starts with the wasm magic.
function embeddedModule(text) {
    const isBase64 = (code) =>
        (code >= 65 && code <= 90) || (code >= 97 && code <= 122) ||
        (code >= 48 && code <= 57) || code === 43 || code === 47 || code === 61;
    let start = -1;
    for (let i = 0; i <= text.length; i++) {
        if (i < text.length && isBase64(text.charCodeAt(i))) {
            if (start < 0) start = i;
            continue;
        }
        if (start >= 0 && i - start >= 4096) {
            const candidate = Buffer.from(text.slice(start, i), 'base64');
            if (candidate.subarray(0, 4).toString('hex') === '0061736d') return candidate;
        }
        start = -1;
    }
    return null;
}

let bytes = null;
if (wasmPath && wasmPath !== '-' && fs.existsSync(wasmPath)) {
    bytes = fs.readFileSync(wasmPath);
    console.log('wasm: separate file, ' + bytes.length + ' bytes');
} else {
    bytes = embeddedModule(js);
    if (!bytes) {
        console.error('FAIL: no separate wasm and no embedded wasm payload found');
        process.exit(1);
    }
    console.log('wasm: embedded, ' + bytes.length + ' bytes');
}
if (bytes.subarray(0, 4).toString('hex') !== '0061736d') {
    console.error('FAIL: payload is not a wasm module');
    process.exit(1);
}
// Hand the validated bytes to the feature probe, which needs a file on disk
// whatever the layout was.
fs.writeFileSync(wasmOut, bytes);

// A bound function's name does not appear in the glue at all: embind stores the
// name given to each .function(...) inside the wasm data section. So the glue is
// only checked for the helpers upstream writes in JavaScript, and the codecs are
// checked in the wasm bytes and then proved for real by the smoke test below,
// which loads the module. (The glue does contain imread, but that one is a
// canvas helper from modules/js/src/helpers.js - asserting it says nothing about
// whether imgcodecs was bound.)
if (!/\bmatFromArray\b/.test(js)) {
    console.error('FAIL: cv.matFromArray is missing - the glue is not an OpenCV js build');
    process.exit(1);
}
if (wantCodecs === 'true' && !bytes.includes(Buffer.from('imdecode'))) {
    console.error('FAIL: imgcodecs requested but no imdecode registration is in the wasm');
    process.exit(1);
}
console.log('verify OK');
