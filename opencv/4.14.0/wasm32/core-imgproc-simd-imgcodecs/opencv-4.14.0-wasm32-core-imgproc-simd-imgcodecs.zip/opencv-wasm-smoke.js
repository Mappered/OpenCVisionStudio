const path = require('path');

// Usage: opencv-wasm-smoke.js <imgcodecs>. The flags this script is asked to
// check are the ones the caller ordered, so a requested feature that turns out
// to be unreachable is a failure and not a footnote.
const wantCodecs = process.argv[2] === 'true';

// A 1x1 PNG. Decoding it from bytes proves the imgcodecs path end to end,
// including the bundled libpng - the reason this option exists is to stop
// routing images through a canvas.
const PNG_1X1 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

// MODULARIZE=1 makes opencv.js a factory returning a promise in current
// emscripten, while older output exports the module object immediately, so
// both shapes are accepted. The timeout keeps a hung runtime from quietly
// eating the job's time budget.
const loaded = require(path.join(__dirname, 'opencv.js'));

function ready(cv) {
    if (typeof cv.Mat === 'function') return Promise.resolve(cv);
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error('runtime did not initialise in 120s')), 120000);
        cv.onRuntimeInitialized = () => { clearTimeout(timer); resolve(cv); };
    });
}

function check(cv) {
    const checks = [];
    const cleanup = [];
    try {
        const m = cv.matFromArray(2, 3, cv.CV_32F, [1, 2, 3, 4, 5, 6]);
        cleanup.push(m);
        const values = Array.from(m.data32F);
        checks.push(['matFromArray', m.rows === 2 && m.cols === 3 && values[5] === 6]);

        // Exercised whatever the flags: catches a broken baseline build.
        const src = cv.Mat.ones(64, 64, cv.CV_8UC1);
        const blurred = new cv.Mat();
        cleanup.push(src, blurred);
        cv.blur(src, blurred, new cv.Size(3, 3));
        checks.push(['blur', blurred.rows === 64 && blurred.cols === 64 && blurred.ucharPtr(32, 32)[0] === 1]);

        if (typeof cv.imdecode === 'function') {
            const png = Buffer.from(PNG_1X1, 'base64');
            const encoded = cv.matFromArray(png.length, 1, cv.CV_8U, Array.from(png));
            const flags = typeof cv.IMREAD_GRAYSCALE === 'number' ? cv.IMREAD_GRAYSCALE : 0;
            const decoded = cv.imdecode(encoded, flags);
            cleanup.push(encoded, decoded);
            checks.push(['imdecode(png)', decoded.rows === 1 && decoded.cols === 1]);
            console.log('imdecode: callable, IMREAD_GRAYSCALE enum ' +
                        (typeof cv.IMREAD_GRAYSCALE === 'number' ? 'present' : 'absent'));
        } else {
            // Not a soft failure: imgcodecs was asked for, and the whole point of
            // it is decoding bytes without going through a canvas.
            console.log('imdecode: not bound');
            checks.push(['imdecode bound', !wantCodecs]);
        }
    } catch (error) {
        console.error('smoke test threw:', error);
        process.exit(1);
    }
    let ok = true;
    for (const [name, passed] of checks) {
        console.log((passed ? 'ok   ' : 'FAIL ') + name);
        if (!passed) ok = false;
    }
    for (const item of cleanup) { try { item.delete(); } catch (error) { /* already gone */ } }
    console.log(ok ? 'OK' : 'FAIL');
    process.exit(ok ? 0 : 1);
}

Promise.resolve(typeof loaded === 'function' ? loaded() : loaded).then(ready).then(check).catch((error) => {
    console.error('smoke test failed:', error);
    process.exit(1);
});
