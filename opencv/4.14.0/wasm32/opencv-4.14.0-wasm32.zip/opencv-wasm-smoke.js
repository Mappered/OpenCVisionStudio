const path = require('path');
const cv = require(path.join(__dirname, 'opencv.js'));

cv.onRuntimeInitialized = () => {
    try {
        const m = cv.matFromArray(2, 3, cv.CV_32F, [1, 2, 3, 4, 5, 6]);
        const values = Array.from(m.data32F);
        const ok = m.rows === 2 && m.cols === 3 && values.length === 6 && values[5] === 6;
        console.log('opencv.js | rows=' + m.rows + ' cols=' + m.cols + ' data=' + values.join(','));
        m.delete();
        console.log(ok ? 'OK' : 'FAIL');
        process.exit(ok ? 0 : 1);
    } catch (error) {
        console.error('smoke test threw:', error);
        process.exit(1);
    }
};
